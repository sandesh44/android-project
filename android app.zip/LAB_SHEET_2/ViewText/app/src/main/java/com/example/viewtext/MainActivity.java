package com.example.viewtext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText inputText;
    TextView textView;
    Button btnSubmit;
    String INPUT_VALUE;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        if (savedInstanceState != null) {

            INPUT_VALUE = savedInstanceState.getString("input_text");
            inputText.setText(INPUT_VALUE);
        }
    }

    public void onClickSubmit(View view) {

        INPUT_VALUE = inputText.getText().toString();

        textView.setText(INPUT_VALUE);

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("input_text", INPUT_VALUE);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Save Or Not");
        builder.setMessage("Do you want to save this? ");
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });
        builder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                inputText.setText("");

            }
        });

        builder.show();




    }
//
//    public void openDialog() {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Save Or Not");
//        builder.setMessage("Do you want to save this? ");
//        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//
//            }
//        });
//        builder.setNegativeButton("Discard", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int id) {
//
//                inputText.setText("");
//
//            }
//        });
//
//        builder.show();
//
//    }
}